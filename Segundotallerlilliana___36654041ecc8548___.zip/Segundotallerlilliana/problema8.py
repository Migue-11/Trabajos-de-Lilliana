Meses_año = ('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 
             'Septiembre', 'Octubre', 'Noviembre', 'Diciembre')

print("Estos son los meses del año")

for meses in Meses_año:
    print(meses)