personas={
    "Rafael":11,
    "Emmanuel":20,
    "Natalia":17,
    "Santiago":16,
    "Juan":22,
    "Manuela":23,
    "Daniela":29
}

mayores= [nombre for nombre, edad in personas.items() if edad > 18 ]

print(mayores)