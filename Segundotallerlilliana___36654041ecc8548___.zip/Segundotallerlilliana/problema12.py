persona = {"nombre": "Miguel",
           "edad": 17,
           "ciudad":"Medellín"
}
persona ["edad"] = 40

print("La nueva edad es:", persona)