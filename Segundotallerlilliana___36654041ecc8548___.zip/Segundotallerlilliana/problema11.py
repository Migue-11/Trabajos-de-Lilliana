persona = {"nombre": "Miguel",
           "edad": 17,
           "ciudad":"Medellín"
}
edad = persona ["edad"]

print("La edad es:", edad)