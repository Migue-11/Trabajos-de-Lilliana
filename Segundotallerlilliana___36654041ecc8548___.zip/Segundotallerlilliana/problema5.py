numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9]

sublimista =  numeros[2:4]

print(sublimista)