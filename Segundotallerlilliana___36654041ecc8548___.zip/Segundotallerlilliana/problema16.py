persona = {"nombre": "Miguel",
    "edad": 17,
    "ciudad": "Medellin"
}

pares = list(persona.items())

print(pares)