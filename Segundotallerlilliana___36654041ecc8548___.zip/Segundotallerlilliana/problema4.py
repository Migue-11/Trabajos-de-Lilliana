numeross=[1, 2, 3, 4, 5]

UltimoElemento = [5]

print("El ultimo elemento de esta lista es:", UltimoElemento)