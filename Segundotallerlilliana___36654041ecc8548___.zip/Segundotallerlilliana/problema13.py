persona = {"nombre": "Miguel",
           "edad": 17,
           "ciudad":"Medellín"
}
del persona ["ciudad"] 

print("La clave eliminada es:", persona)