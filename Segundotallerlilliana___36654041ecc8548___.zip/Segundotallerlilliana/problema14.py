clave = ["nombre", "edad", "ciudad"]

print (clave)