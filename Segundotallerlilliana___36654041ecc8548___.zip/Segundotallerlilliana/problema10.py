persona = {"nombre": "Miguel",
           "edad": 17,
           "ciudad":"Medellín"
}

print ("nombre", persona ["nombre"])
print ("edad", persona ["edad"])
print ("ciudad", persona ["nombre"])
