numeros=[1, 2, 4, 5, 6, 7, 8, 9]
print(numeros)
print("Esta es la nueva lista, eliminaste un numero")