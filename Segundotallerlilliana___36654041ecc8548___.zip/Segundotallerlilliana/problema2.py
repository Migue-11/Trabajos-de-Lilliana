mixta =["Hola y Bienvenido a este mundo", 2, 10.122]
print(mixta)