numeross=[1, 2, 3, 4, 5]

tercerElemento = [3]

print("El tercer elemento de esta lista es:", tercerElemento)