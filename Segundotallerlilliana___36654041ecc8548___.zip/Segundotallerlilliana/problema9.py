Meses_año = ('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 
             'Septiembre', 'Octubre', 'Noviembre', 'Diciembre')

Segundo_mes = Meses_año[1]

print("El segundo mes del año es:", Segundo_mes)
