cuadrados=[x**2 for x in range(1,6)]

print(cuadrados)