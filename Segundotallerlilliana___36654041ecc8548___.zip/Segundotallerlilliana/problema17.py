Numeros_Pares=[x for x in range (1,11) if x %2==0]

print(Numeros_Pares)