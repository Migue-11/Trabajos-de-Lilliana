Valores = ["nombre", "edad", "ciudad"]

print (Valores)