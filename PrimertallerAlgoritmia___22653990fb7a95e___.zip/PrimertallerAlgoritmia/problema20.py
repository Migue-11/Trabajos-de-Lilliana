def convertir_a_mayusculas(cadena):
    return cadena.upper()

def convertir_a_minusculas(cadena):
    return cadena.lower()

cadena_original = "¿Hola Mundo!!"
cadena_en_mayusculas = convertir_a_mayusculas(cadena_original)
cadena_en_minusculas = convertir_a_minusculas(cadena_original)

print("Original: ", cadena_original)
print("En Mayúsculas: ", cadena_en_mayusculas)
print("En Minúsculas: ", cadena_en_minusculas)
