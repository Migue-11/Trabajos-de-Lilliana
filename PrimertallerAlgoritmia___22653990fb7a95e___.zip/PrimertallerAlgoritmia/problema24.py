archivo_entrada = "agenda.csv"  
archivo_directo = "directo_agenda.csv"  

with open(archivo_entrada, "r") as f_entrada:
    lineas = f_entrada.readlines()

with open(archivo_directo, "w") as f_directo:
    for i, linea in enumerate(lineas):
        f_directo.write(f"{i + 1},{linea}")

print("El archivo se ha copiado a directo_agenda manteniendo la posición relativa de cada registro.")
