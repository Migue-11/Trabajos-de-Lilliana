import math

numero_1 = 18
numero_2 = 30

mcd = math.gcd(numero_1, numero_2)

print("El maximo comun divisor de", numero_1, "y", numero_2, "es:", mcd)    