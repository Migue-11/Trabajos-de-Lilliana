def contar_ocurrencias_palabras(texto):
    ocurrencias_a = 0
    ocurrencias_an = 0
    ocurrencias_and = 0

    lineas = texto.split('\n')

    for linea in lineas:
        palabras = linea.split()  

        for palabra in palabras:
            palabra = palabra.lower() 
            if palabra == 'a':
                ocurrencias_a += 1
            elif palabra == 'an':
                ocurrencias_an += 1
            elif palabra == 'and':
                ocurrencias_and += 1

    return ocurrencias_a, ocurrencias_an, ocurrencias_and

texto = """
This is a sample text.
Here's another example containing 'an' and 'and' as well.
"""

a, an, and_ = contar_ocurrencias_palabras(texto)

print("Número de ocurrencias de 'a':", a)
print("Número de ocurrencias de 'an':", an)
print("Número de ocurrencias de 'and':", and_)
