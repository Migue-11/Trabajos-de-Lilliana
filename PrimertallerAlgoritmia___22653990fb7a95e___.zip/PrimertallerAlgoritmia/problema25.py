archivo = "agenda.csv"  
with open(archivo, "r") as f:
    lineas = f.readlines()

print("Contenido actual de la agenda:")
for linea in lineas:
    print(linea.strip())

indice_modificar = int(input("Ingrese el número de registro a modificar: ")) - 1  # Restamos 1 porque las listas son 0 indexadas.
nuevo_contenido = input("Ingrese la nueva información del registro: ")

if 0 <= indice_modificar < len(lineas):
    lineas[indice_modificar] = nuevo_contenido + "\n"

with open(archivo, "w") as f:
    f.writelines(lineas)

print("El registro ha sido modificado con éxito.")
