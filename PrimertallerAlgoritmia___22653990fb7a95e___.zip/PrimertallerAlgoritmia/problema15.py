matriz = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 10, 11, 12],
    [13, 14, 15, 16]
]

suma_diagonal = 0

for i in range(4):
    suma_diagonal += matriz[i][i]

print("La suma de la diagonal es:", suma_diagonal)
