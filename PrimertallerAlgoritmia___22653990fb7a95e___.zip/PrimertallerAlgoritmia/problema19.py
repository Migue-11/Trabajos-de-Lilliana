def arabigo_a_romano(numero):
    arabigos = [1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000]
    romanos = ["I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"]
    resultado = ""

    i = len(arabigos) - 1

    while numero > 0:
        repeticiones = numero // arabigos[i]
        numero %= arabigos[i]
        resultado += romanos[i] * repeticiones
        i -= 1

    return resultado

def romano_a_arabigo(romano):
    romanos = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    resultado = 0
    prev_valor = 0

    for letra in romano:
        valor = romanos[letra]
        if valor > prev_valor:
            resultado += valor - 2 * prev_valor
        else:
            resultado += valor
        prev_valor = valor

    return resultado

numero_arabigo = 1987
numero_romano = "MMXXIII"

romano_convertido = arabigo_a_romano(numero_arabigo)
arabigo_convertido = romano_a_arabigo(numero_romano)

print(f"{numero_arabigo} en números romanos es {romano_convertido}")
print(f"{numero_romano} en números arábigos es {arabigo_convertido}")
