def Media():
    Primer_numero = float(input("Digite el primer numero:"))
    Segundo_numero = float(input("Digite el segundo numero:"))
    Tercer_numero = float(input("Digite el tercer numero:"))
    media = (Primer_numero + Segundo_numero + Tercer_numero)/3
    
    return media

resultado = Media()
print("La media de los tres numeros es:", resultado)