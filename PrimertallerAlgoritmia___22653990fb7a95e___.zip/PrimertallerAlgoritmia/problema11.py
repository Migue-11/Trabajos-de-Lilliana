def division_entera_y_resta (dividendo, divisor):
    if divisor == 0:
        print("No se puede dividir por cero.")
    else:
        cociente = 0  
        resto = dividendo  
        
        while resto >= divisor:
            resto = resto - divisor
            cociente = cociente + 1  

        print(f"División entera: {cociente}")
        print(f"Resto: {resto}")

dividendo = 18
divisor = 30

division_entera_y_resta (dividendo, divisor)
