def encontrar_mayorvalor(M):
    if len(M) == 0:
        return None 

    maximo = M[0] 
    for elemento in M:
        if elemento > maximo:
            maximo = elemento

    return maximo

lista = [8, 2, 12, 5, 7, 3, 90]

mayor_valor = encontrar_mayorvalor(lista)

if mayor_valor is not None:
    print(f"El mayor valor en la lista es: {mayor_valor}")
else:
    print("La lista está vacía.")
