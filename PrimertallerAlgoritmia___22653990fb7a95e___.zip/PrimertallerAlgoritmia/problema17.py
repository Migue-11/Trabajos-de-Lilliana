def calcular_calificacion_media(calificaciones):
    if len(calificaciones) == 0:
        return None  

    suma = sum(calificaciones)
    media = suma / len(calificaciones)
    
    return media

def imprimir_calificaciones_y_diferencia(estudiantes, calificaciones):
    media = calcular_calificacion_media(calificaciones)
    
    if media is not None:
        print("Calificación media:", media)
        print("Calificaciones y diferencia con la media:")
        for i in range(len(estudiantes)):
            diferencia = calificaciones[i] - media
            print(f"{estudiantes[i]}: {calificaciones[i]}, Diferencia: {diferencia}")
    else:
        print("No hay calificaciones para calcular.")

estudiantes = ["Estudiante1", "Estudiante2", "Estudiante3", "Estudiante4"]
calificaciones = [85, 92, 78, 90]

imprimir_calificaciones_y_diferencia(estudiantes, calificaciones)
