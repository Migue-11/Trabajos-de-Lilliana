def Palindromo(cadena):
    cadena = cadena.replace(" ", "").lower()
    
    return cadena == cadena[::-1]

cadena = "Anilina"
if Palindromo(cadena):
    print(f'"{cadena}" Es un palíndromo.')
else:
    print(f'"{cadena}" No es un palíndromo.')
