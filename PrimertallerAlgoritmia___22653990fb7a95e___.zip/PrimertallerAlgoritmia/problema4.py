def numero_mayor(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2
number1 = 18 
number2 = 30

mayornum = numero_mayor(number1, number2)
print("El numero mayor es", mayornum)
