def Potencia(x, n):
    return x ** n
x = 1.8
n = 30

resultado = Potencia(x, n)
print("El resultado de", x, "elevado a la potencia", n, "es:", resultado)