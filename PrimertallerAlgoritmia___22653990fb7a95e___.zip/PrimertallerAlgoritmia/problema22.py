import csv

def crear_agenda(archivo):
    with open(archivo, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Nombre", "Dirección", "Ciudad", "Código Postal", "Teléfono", "Edad"])
    print(f"Se ha creado el archivo de agenda: {archivo}")

def agregar_registro(archivo, registro):
    with open(archivo, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(registro)

def listar_agenda(archivo):
    with open(archivo, 'r', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            print(", ".join(row))

def buscar_registro(archivo, nombre):
    with open(archivo, 'r', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if nombre in row[0]:
                print(", ".join(row))
                return

def main():
    archivo = "agenda.csv"
    crear_agenda(archivo)

    while True:
        print("\nOpciones:")
        print("1. Agregar un registro")
        print("2. Listar registros")
        print("3. Buscar registro por nombre")
        print("4. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            nombre = input("Nombre: ")
            direccion = input("Dirección: ")
            ciudad = input("Ciudad: ")
            codigo_postal = input("Código Postal: ")
            telefono = input("Teléfono: ")
            edad = input("Edad: ")
            registro = [nombre, direccion, ciudad, codigo_postal, telefono, edad]
            agregar_registro(archivo, registro)
            print("Registro agregado.")
        elif opcion == "2":
            print("\nRegistros en la agenda:")
            listar_agenda(archivo)
        elif opcion == "3":
            nombre = input("Ingrese el nombre a buscar: ")
            buscar_registro(archivo, nombre)
        elif opcion == "4":
            break
        else:
            print("Opción no válida. Inténtelo de nuevo.")

if __name__ == "__main__":
    main()
