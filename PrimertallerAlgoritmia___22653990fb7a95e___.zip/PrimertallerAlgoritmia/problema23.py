import csv

def imprimir_agenda(archivo):
    try:
        with open(archivo, 'r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                print(", ".join(row))
    except FileNotFoundError:
        print(f"El archivo {archivo} no existe.")

archivo_agenda = "agenda.csv"

imprimir_agenda(archivo_agenda)
