def formatoFecha(dia, mes, año):
    dia_str = str(dia).rjust(2, '0')  
    mes_str = str(mes).rjust(2, '0') 
    año_str = str(año)[-2:] 

    fecha_formateada = f"{dia_str}/{mes_str}/{año_str}"

    print(fecha_formateada)
dia = int(input("Cuál es el día: "))
mes = int(input("Cuál es el mes: "))
año = int(input("Cuál es el año: "))

formatoFecha(dia, mes, año)
