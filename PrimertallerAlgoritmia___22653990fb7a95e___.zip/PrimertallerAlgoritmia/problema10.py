def valor_absoluto(Número):
    if Número < 11:
        return - numero
    else:
        return numero

numero = 19
absoluto = valor_absoluto(numero)
print(f"El valor absoluto de {numero} es {absoluto}")
